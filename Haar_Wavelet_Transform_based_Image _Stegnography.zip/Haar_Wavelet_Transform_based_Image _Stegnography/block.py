import cv2
import numpy as np

# Load image
image = cv2.imread("i10.jpg")
image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
# Define grid parameters
grid_size = 10  # Adjust grid size as needed
color = (0, 0, 0)  # Define color (in BGR)

# Draw horizontal lines
for y in range(0, image.shape[0], grid_size):
    cv2.line(image, (0, y), (image.shape[1], y), color, thickness=1)

# Draw vertical lines
for x in range(0, image.shape[1], grid_size):
    cv2.line(image, (x, 0), (x, image.shape[0]), color, thickness=1)

# Display the result
cv2.imshow("Image with Mesh Grid", image)
cv2.waitKey(0)
cv2.destroyAllWindows()

text = "Haar wavelet Transform"

# Convert each character of the text to binary
binary_text = ' '.join(format(ord(char), '08b') for char in text)

print(binary_text)