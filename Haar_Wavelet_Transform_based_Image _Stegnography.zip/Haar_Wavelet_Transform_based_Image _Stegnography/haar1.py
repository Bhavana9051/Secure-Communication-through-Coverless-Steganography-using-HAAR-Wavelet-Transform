import numpy as np
from PIL import Image
import pywt

def embed_message_in_image(cover_image_path, message):
    cover_image = Image.open(cover_image_path).convert('L')  # Convert to grayscale
    width, height = cover_image.size

    stego_image = np.array(cover_image)

    # Convert the message to binary
    binary_message = ''.join(format(ord(char), '08b') for char in message)

    # Ensure the message can fit into the stego image
    if len(binary_message) > width * height * 3:
        raise ValueError("Message is too large for the cover image")

    # Haar wavelet transform on the cover image
    coeffs = pywt.dwt2(stego_image, 'haar')
    LL, (LH, HL, HH) = coeffs

    # Embed the binary message in the LL (approximation) subband
    reshaped_message = [int(bit) for bit in binary_message[:len(LL.flat)]]

    # Convert the LL coefficients to uint8
    LL = np.round(LL).astype(np.uint8)

    LL_flat = LL.flat
    for j in range(len(reshaped_message)):
        if reshaped_message[j] == 1:
            LL_flat[j] |= 1
        else:
            LL_flat[j] &= np.uint8(254)

    # Inverse Haar wavelet transform
    coeffs = LL, (LH, HL, HH)
    stego_image = pywt.idwt2(coeffs, 'haar')

    stego_image = np.round(stego_image).astype(np.uint8)
    stego_image = Image.fromarray(stego_image)
    stego_image.save("cat_50.jpeg")

cover_image_path = "C:/Users/hp/Desktop/mini_sem6/Haar_Wavelet_Transform_based_Image _Stegnography/cat.jpg"
message = "The quick brown fox jumps over the lazy dog. The end of a sentence."
embed_message_in_image(cover_image_path, message)
