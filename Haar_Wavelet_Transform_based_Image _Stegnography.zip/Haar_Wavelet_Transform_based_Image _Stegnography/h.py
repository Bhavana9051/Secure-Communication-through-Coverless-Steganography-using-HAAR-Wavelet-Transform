import cv2
import numpy as np
import pywt

def convert_to_grayscale(image):
    return cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

def embed_text(image, text):
    # Resize text to match the shape of the image block
    text_resized = cv2.resize(text, (image.shape[1], image.shape[0]))

    # Embed text into image block
    # Example: Just concatenate the text to the image
    embedded_image = np.concatenate((image, text_resized), axis=1)
    return embedded_image

def extract_text(embedded_image, text_length):
    # Extract text from the embedded image
    extracted_text = embedded_image[:, -text_length:]
    return extracted_text

def apply_haar_wavelet_transform(image):
    coeffs = pywt.dwt2(image, 'haar')
    LL, (LH, HL, HH) = coeffs
    return coeffs

def inverse_haar_wavelet_transform(coeffs):
    reconstructed_image = pywt.idwt2(coeffs, 'haar')
    return reconstructed_image

def segment_image_into_blocks(image, block_size=(3, 3)):
    # Crop the image into blocks of specified size
    h, w = image.shape
    new_h = (h // block_size[0]) * block_size[0]
    new_w = (w // block_size[1]) * block_size[1]
    image = image[:new_h, :new_w]
    blocks = [image[i:i+block_size[0], j:j+block_size[1]] for i in range(0, new_h, block_size[0]) 
              for j in range(0, new_w, block_size[1])]
    return np.array(blocks)

def visualize_segmented_blocks(blocks):
    # Create a visual representation of the segmented blocks
    num_blocks = len(blocks)
    num_per_row = int(np.sqrt(num_blocks))
    max_val = np.max(blocks)
    min_val = np.min(blocks)
    blocks = (blocks - min_val) / (max_val - min_val) * 255
    blocks = blocks.astype(np.uint8)
    output_image = np.hstack(blocks[:num_per_row])
    for i in range(1, num_per_row):
        row_image = np.hstack(blocks[i*num_per_row:(i+1)*num_per_row])
        output_image = np.vstack((output_image, row_image))
    cv2.imshow('Segmented Blocks', output_image)
    cv2.waitKey(0)

    return output_image

def main():
    # Load image
    image = cv2.imread('i10.jpg')

    # Display original image
    cv2.imshow('Original Image', image)
    cv2.waitKey(0)

    # Convert to grayscale
    grayscale_image = convert_to_grayscale(image)
    cv2.imshow('Grayscale Image', grayscale_image)
    cv2.waitKey(0)

    # Apply Haar wavelet transform
    coeffs = apply_haar_wavelet_transform(grayscale_image)
    LL, (LH, HL, HH) = coeffs

    # Display Haar transformed image
    cv2.imshow('Haar Transformed Image (LL)', LL)
    cv2.imshow('Haar Transformed Image (LH)', LH)
    cv2.imshow('Haar Transformed Image (HL)', HL)
    cv2.imshow('Haar Transformed Image (HH)', HH)
    cv2.waitKey(0)

    # Prompt the user to enter a text message
    user_text = input("Enter a text message: ")

    # Convert the text message to binary with "@" as a word separator
    binary_text = ''.join(format(ord(char), '08b') for char in user_text)

    # Convert the binary text to a numpy array
    text = np.array([int(bit) for bit in binary_text])

    # Segment the image into 3x3 blocks
    blocks = segment_image_into_blocks(LL)

    # Embed text into the segmented blocks
    embedded_blocks = [embed_text(block, text) for block in blocks]

    # Reconstruct the image from blocks
    reconstructed_coeffs = (np.asarray(embedded_blocks), (LH, HL, HH))
    reconstructed_image = inverse_haar_wavelet_transform(reconstructed_coeffs)

    # Extract text from the reconstructed image
    extracted_text = extract_text(reconstructed_image, len(text))

    # Visualize segmented blocks
    segmented_blocks_image = visualize_segmented_blocks(blocks)

    # Display reconstructed image
    cv2.imshow('Reconstructed Image', reconstructed_image.astype(np.uint8))
    cv2.waitKey(0)

    # Display extracted text
    print("Extracted Text:", extracted_text)

    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
