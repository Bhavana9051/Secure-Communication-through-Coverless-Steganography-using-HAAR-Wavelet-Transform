import numpy as np
import matplotlib.pyplot as plt

# Sample data: 9 blocks, each with 81 values
blocks = np.random.randint(0, 256, size=(9, 81))

# Reshape the data into a 3x3 grid
blocks_reshaped = blocks.reshape(3, 3, 9, 9)

# Create a figure and axis
fig, ax = plt.subplots(figsize=(10, 10))

# Plot each block
for i in range(3):
    for j in range(3):
        values = blocks_reshaped[i, j]
        ax.text(j * 9 + 4, -i * 9 - 4, '\n'.join(' '.join(f'{val:3d}' for val in row) for row in values),
                ha='left', va='top')

# Set the limits of the plot
ax.set_xlim(-1, 27)
ax.set_ylim(-27, 1)

# Hide the axes
ax.axis('off')

plt.show()
